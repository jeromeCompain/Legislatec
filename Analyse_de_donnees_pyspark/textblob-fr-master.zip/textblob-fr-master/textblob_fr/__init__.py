# -*- coding: utf-8 -*-
from __future__ import absolute_import
from textblob_fr.taggers import PatternTagger
from textblob_fr.sentiments import PatternAnalyzer

__version__ = '0.2.0'
__author__ = 'Steven Loria'
__license__ = "MIT"
