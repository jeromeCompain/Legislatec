Changelog
---------

0.2.0 (10/27/2013)
++++++++++++++++++

* Compatibility with TextBlob>=0.8.0.

0.1.0 (09/25/2013)
++++++++++++++++++

* First release
* Basically a thin, Py3-compatible wrapper around pattern.fr. Hooks to pattern's tagger and sentiment analyzer.


0.0.1 (09/22/2013)
++++++++++++++++++

* Experimental release.
